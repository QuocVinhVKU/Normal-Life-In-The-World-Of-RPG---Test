Thank you for your download!

Please note that the blank space on the tileset is there for future additions to the tileset, or if you'd like to add to it yourself. This will hopefully ensure that reimporting the updated tileset into your project won't cause any issues (existing tiles will remain in their current locations on the tileset).

License
These assets may be used in both personal and commercial projects.
You may edit and add to them as needed.
Credit is optional.
You may not redistribute or re-sell these assets, with or without modifications.

If you would like to give credit in your project, please credit to either Daniel James Freer or Pond Games.

Thanks again!
-Dan

2021 Pond Games PTY LTD